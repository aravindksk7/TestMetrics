-- ============================================================
-- Xray ETL Step 6: Data Quality Checks
-- Run after every load cycle before triggering Power BI refresh
-- FAIL rows must be resolved before report use
-- ============================================================
USE XrayTestMetrics;
GO

IF OBJECT_ID('tempdb..#DQ') IS NOT NULL DROP TABLE #DQ;
CREATE TABLE #DQ (
    CheckType   VARCHAR(10),
    TableName   VARCHAR(60),
    Description VARCHAR(200),
    IssueCount  INT
);

-- ── A. Referential integrity ────────────────────────────────
INSERT #DQ SELECT 'FK','FactTestRun',
    'Orphan TestKey — TestID missing in DimTest',
    COUNT(*) FROM dbo.FactTestRun f
    WHERE NOT EXISTS (SELECT 1 FROM dbo.DimTest d WHERE d.TestKey = f.TestKey);

INSERT #DQ SELECT 'FK','FactTestRun',
    'Orphan ReleaseKey — ReleaseID missing in DimRelease',
    COUNT(*) FROM dbo.FactTestRun f
    WHERE NOT EXISTS (SELECT 1 FROM dbo.DimRelease d WHERE d.ReleaseKey = f.ReleaseKey);

INSERT #DQ SELECT 'FK','FactTestRun',
    'Orphan EnvironmentKey — missing in DimEnvironment',
    COUNT(*) FROM dbo.FactTestRun f
    WHERE NOT EXISTS (SELECT 1 FROM dbo.DimEnvironment d WHERE d.EnvironmentKey = f.EnvironmentKey);

INSERT #DQ SELECT 'FK','FactTestRun',
    'ExecutionDateKey not in DimDate',
    COUNT(*) FROM dbo.FactTestRun f
    WHERE NOT EXISTS (SELECT 1 FROM dbo.DimDate d WHERE d.DateKey = f.ExecutionDateKey);

INSERT #DQ SELECT 'FK','FactTestRun',
    'Orphan StatusKey — missing in DimStatus',
    COUNT(*) FROM dbo.FactTestRun f
    WHERE NOT EXISTS (SELECT 1 FROM dbo.DimStatus d WHERE d.StatusKey = f.StatusKey);

INSERT #DQ SELECT 'FK','FactRequirementCoverage',
    'Orphan RequirementKey — missing in DimRequirement',
    COUNT(*) FROM dbo.FactRequirementCoverage f
    WHERE NOT EXISTS (SELECT 1 FROM dbo.DimRequirement d WHERE d.RequirementKey = f.RequirementKey);

INSERT #DQ SELECT 'FK','FactRequirementCoverage',
    'Orphan ReleaseKey — missing in DimRelease',
    COUNT(*) FROM dbo.FactRequirementCoverage f
    WHERE NOT EXISTS (SELECT 1 FROM dbo.DimRelease d WHERE d.ReleaseKey = f.ReleaseKey);

INSERT #DQ SELECT 'FK','FactDefectLink',
    'Orphan TestRunKey — missing in FactTestRun',
    COUNT(*) FROM dbo.FactDefectLink f
    WHERE NOT EXISTS (SELECT 1 FROM dbo.FactTestRun t WHERE t.TestRunKey = f.TestRunKey);

INSERT #DQ SELECT 'FK','FactDefectLink',
    'Orphan DefectKey — missing in DimDefect',
    COUNT(*) FROM dbo.FactDefectLink f
    WHERE NOT EXISTS (SELECT 1 FROM dbo.DimDefect d WHERE d.DefectKey = f.DefectKey);

INSERT #DQ SELECT 'FK','DimApplication',
    'Orphan ProgramKey — missing in DimProgram',
    COUNT(*) FROM dbo.DimApplication a
    WHERE NOT EXISTS (SELECT 1 FROM dbo.DimProgram p WHERE p.ProgramKey = a.ProgramKey);

-- ── B. Null checks on mandatory fields ──────────────────────
INSERT #DQ SELECT 'NULL','FactTestRun',
    'NULL ApplicationKey — application not resolved',
    COUNT(*) FROM dbo.FactTestRun WHERE ApplicationKey IS NULL;

INSERT #DQ SELECT 'NULL','FactTestRun',
    'NULL DurationMinutes — may affect avg duration measure',
    COUNT(*) FROM dbo.FactTestRun WHERE DurationMinutes IS NULL;

INSERT #DQ SELECT 'NULL','DimTest',
    'NULL ApplicationKey — test not linked to application',
    COUNT(*) FROM dbo.DimTest WHERE ApplicationKey IS NULL;

INSERT #DQ SELECT 'NULL','DimRequirement',
    'NULL ApplicationKey — requirement not linked to application',
    COUNT(*) FROM dbo.DimRequirement WHERE ApplicationKey IS NULL;

-- ── C. Business rule violations ─────────────────────────────
INSERT #DQ SELECT 'BIZ','FactTestRun',
    'IsBlocked=1 but StatusCategory is not Blocked',
    COUNT(*) FROM dbo.FactTestRun ftr
    JOIN dbo.DimStatus ds ON ftr.StatusKey = ds.StatusKey
    WHERE ftr.IsBlocked = 1 AND ds.StatusCategory <> 'Blocked';

INSERT #DQ SELECT 'BIZ','FactTestRun',
    'RunSequence < 1 — invalid execution sequence',
    COUNT(*) FROM dbo.FactTestRun WHERE RunSequence < 1;

INSERT #DQ SELECT 'BIZ','FactTestRun',
    'DurationMinutes <= 0 — invalid duration',
    COUNT(*) FROM dbo.FactTestRun WHERE DurationMinutes IS NOT NULL AND DurationMinutes <= 0;

INSERT #DQ SELECT 'BIZ','DimRelease',
    'PlannedEndDate before PlannedStartDate',
    COUNT(*) FROM dbo.DimRelease
    WHERE PlannedEndDate IS NOT NULL AND PlannedStartDate IS NOT NULL
      AND PlannedEndDate < PlannedStartDate;

INSERT #DQ SELECT 'BIZ','FactRequirementCoverage',
    'CoveredFlag=1 AND FailedCoverageFlag=1 — conflicting flags',
    COUNT(*) FROM dbo.FactRequirementCoverage
    WHERE CoveredFlag = 1 AND FailedCoverageFlag = 1;

INSERT #DQ SELECT 'BIZ','FactRequirementCoverage',
    'CoveredFlag=1 AND PartialCoverageFlag=1 — conflicting flags',
    COUNT(*) FROM dbo.FactRequirementCoverage
    WHERE CoveredFlag = 1 AND PartialCoverageFlag = 1;

-- ── D. Duplicate checks ─────────────────────────────────────
INSERT #DQ SELECT 'DUP','FactTestRun',
    'Duplicate ExecutionID — idempotency key violated',
    COUNT(*) - COUNT(DISTINCT ExecutionID) FROM dbo.FactTestRun;

INSERT #DQ SELECT 'DUP','DimTest',
    'Duplicate TestID',
    COUNT(*) - COUNT(DISTINCT TestID) FROM dbo.DimTest;

INSERT #DQ SELECT 'DUP','DimRequirement',
    'Duplicate RequirementID',
    COUNT(*) - COUNT(DISTINCT RequirementID) FROM dbo.DimRequirement;

-- ── E. Volume info ──────────────────────────────────────────
INSERT #DQ SELECT 'VOL','DimProgram',          'Row count', COUNT(*) FROM dbo.DimProgram;
INSERT #DQ SELECT 'VOL','DimApplication',      'Row count', COUNT(*) FROM dbo.DimApplication;
INSERT #DQ SELECT 'VOL','DimSquad',            'Row count', COUNT(*) FROM dbo.DimSquad;
INSERT #DQ SELECT 'VOL','DimRelease',          'Row count', COUNT(*) FROM dbo.DimRelease;
INSERT #DQ SELECT 'VOL','DimTest',             'Row count', COUNT(*) FROM dbo.DimTest;
INSERT #DQ SELECT 'VOL','DimRequirement',      'Row count', COUNT(*) FROM dbo.DimRequirement;
INSERT #DQ SELECT 'VOL','DimDefect',           'Row count', COUNT(*) FROM dbo.DimDefect;
INSERT #DQ SELECT 'VOL','FactTestRun',         'Row count', COUNT(*) FROM dbo.FactTestRun;
INSERT #DQ SELECT 'VOL','FactRequirementCoverage','Row count',COUNT(*) FROM dbo.FactRequirementCoverage;
INSERT #DQ SELECT 'VOL','FactDefectLink',      'Row count', COUNT(*) FROM dbo.FactDefectLink;
INSERT #DQ SELECT 'VOL','FactCycleSnapshot',   'Row count', COUNT(*) FROM dbo.FactCycleSnapshot;
INSERT #DQ SELECT 'VOL','DimDate',             'Row count', COUNT(*) FROM dbo.DimDate;

-- ── Results ─────────────────────────────────────────────────
SELECT
    CheckType,
    TableName,
    Description,
    IssueCount,
    CASE
        WHEN CheckType = 'VOL'    THEN 'INFO'
        WHEN IssueCount = 0       THEN 'PASS'
        WHEN CheckType = 'NULL'   THEN 'WARN — review'
        ELSE                           'FAIL — fix before PBI refresh'
    END AS Result
FROM #DQ
ORDER BY
    CASE CheckType
        WHEN 'FK'   THEN 1
        WHEN 'DUP'  THEN 2
        WHEN 'BIZ'  THEN 3
        WHEN 'NULL' THEN 4
        ELSE 5
    END,
    IssueCount DESC;

DROP TABLE #DQ;
GO
PRINT 'Data quality check complete. All FAIL rows must be resolved before Power BI refresh.';
GO
