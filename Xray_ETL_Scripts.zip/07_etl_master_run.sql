-- ============================================================
-- Xray ETL Master Runner
-- Schedule via SQL Server Agent — nightly after CSV export
-- Each step is a separate SQL Agent job step for isolation
-- ============================================================
USE XrayTestMetrics;
GO

DECLARE @StartTime  DATETIME2        = SYSUTCDATETIME();
DECLARE @BatchID    UNIQUEIDENTIFIER = NEWID();
DECLARE @Step       VARCHAR(100);

BEGIN TRY

    PRINT '=== Xray ETL Start: ' + CONVERT(VARCHAR,@StartTime,120) + ' ===';
    PRINT 'BatchID: ' + CAST(@BatchID AS VARCHAR(36));

    -- ── Step 1: Verify staging tables have data ─────────────
    SET @Step = 'Pre-flight check';
    IF (SELECT COUNT(*) FROM stg.TestRun) = 0
        RAISERROR ('stg.TestRun is empty. Bulk load must run before ETL.', 16, 1);

    PRINT '[Step 1] Pre-flight PASSED — ' + CONVERT(VARCHAR,SYSUTCDATETIME(),120);

    -- ── Step 2: Dimensions (run script 03) ──────────────────
    SET @Step = 'Load Dimensions';
    -- SQL Agent: add script 03_load_dimensions.sql as separate job step
    PRINT '[Step 2] Dimensions loaded — ' + CONVERT(VARCHAR,SYSUTCDATETIME(),120);

    -- ── Step 3: Facts (run script 04) ───────────────────────
    SET @Step = 'Load Facts';
    -- SQL Agent: add script 04_load_facts.sql as separate job step
    PRINT '[Step 3] Facts loaded — ' + CONVERT(VARCHAR,SYSUTCDATETIME(),120);

    -- ── Step 4: DQ gate ─────────────────────────────────────
    SET @Step = 'Data Quality Check';
    DECLARE @FailCount INT;
    SELECT @FailCount = COUNT(*)
    FROM (
        SELECT 1 FROM dbo.FactTestRun f
        WHERE NOT EXISTS (SELECT 1 FROM dbo.DimTest d WHERE d.TestKey=f.TestKey)
        UNION ALL
        SELECT 1 FROM dbo.FactTestRun f
        WHERE NOT EXISTS (SELECT 1 FROM dbo.DimRelease d WHERE d.ReleaseKey=f.ReleaseKey)
        UNION ALL
        SELECT 1 FROM dbo.FactTestRun f
        WHERE NOT EXISTS (SELECT 1 FROM dbo.DimDate d WHERE d.DateKey=f.ExecutionDateKey)
    ) x;

    IF @FailCount > 0
        RAISERROR ('DQ gate FAILED: %d referential integrity violations found.', 16, 1, @FailCount);

    PRINT '[Step 4] DQ gate PASSED — ' + CONVERT(VARCHAR,SYSUTCDATETIME(),120);

    -- ── Step 5: Summary ─────────────────────────────────────
    SELECT
        'ETL Complete'                                    AS Status,
        CONVERT(VARCHAR,@StartTime,120)                   AS StartTime,
        CONVERT(VARCHAR,SYSUTCDATETIME(),120)             AS EndTime,
        DATEDIFF(SECOND,@StartTime,SYSUTCDATETIME())      AS ElapsedSeconds,
        (SELECT COUNT(*) FROM dbo.FactTestRun)            AS FactTestRun_Rows,
        (SELECT COUNT(*) FROM dbo.FactRequirementCoverage)AS FactReqCov_Rows,
        (SELECT COUNT(*) FROM dbo.FactDefectLink)         AS FactDefectLink_Rows,
        (SELECT COUNT(*) FROM dbo.FactCycleSnapshot)      AS FactSnapshot_Rows,
        (SELECT MAX(FullDate) FROM dbo.DimDate
         WHERE DateKey IN (SELECT MAX(ExecutionDateKey) FROM dbo.FactTestRun))
                                                          AS LatestExecutionDate;

    INSERT stg.ETLLog (BatchID,TableName,StepName,Status)
    VALUES (@BatchID,'MASTER','Complete','Success');

END TRY
BEGIN CATCH
    DECLARE @ErrMsg NVARCHAR(MAX) = ERROR_MESSAGE();
    INSERT stg.ETLLog (BatchID,TableName,StepName,Status,ErrorMessage)
    VALUES (@BatchID,'MASTER',@Step,'Failed',@ErrMsg);
    RAISERROR ('ETL FAILED at [%s]: %s', 16, 1, @Step, @ErrMsg);
END CATCH;
GO

-- ── ETL audit trail query ───────────────────────────────────
-- Run this to review the last 5 batch runs
SELECT TOP 50
    CAST(BatchID AS VARCHAR(36)) AS BatchID,
    TableName, StepName, RowsInserted,
    StartTime, EndTime,
    DATEDIFF(SECOND,StartTime,EndTime) AS DurationSec,
    Status, LEFT(ISNULL(ErrorMessage,''),100) AS ErrorSnippet
FROM stg.ETLLog
ORDER BY LogID DESC;
GO
