-- ============================================================
-- Xray ETL Step 2: Bulk Load CSV Files into Staging
-- Purpose : Load raw Jira/Xray CSV exports into stg schema
-- Before  : Update @BasePath to your CSV export folder
-- After   : Check error files in errors\ subfolder
-- ============================================================
USE XrayTestMetrics;
GO

-- !! UPDATE THIS PATH to match your server export folder !!
-- DECLARE @BasePath NVARCHAR(500) = 'C:\XrayExports\';

-- ── Truncate all staging tables before reload ───────────────
TRUNCATE TABLE stg.Program;
TRUNCATE TABLE stg.Application;
TRUNCATE TABLE stg.Squad;
TRUNCATE TABLE stg.Release;
TRUNCATE TABLE stg.Environment;
TRUNCATE TABLE stg.Tester;
TRUNCATE TABLE stg.Requirement;
TRUNCATE TABLE stg.Test;
TRUNCATE TABLE stg.Defect;
TRUNCATE TABLE stg.TestRun;
TRUNCATE TABLE stg.RequirementCoverage;
TRUNCATE TABLE stg.DefectLink;
PRINT 'Staging tables truncated.';
GO

-- ── programs.csv ───────────────────────────────────────────
-- Columns: ProgramID,ProgramName,PortfolioName,IsActive
BULK INSERT stg.Program
FROM 'C:\XrayExports\programs.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR   = '0x0a',
    FIRSTROW        = 2,
    CODEPAGE        = '65001',
    TABLOCK,
    ERRORFILE       = 'C:\XrayExports\errors\programs_err.txt'
);
PRINT 'Loaded stg.Program: ' + CAST(@@ROWCOUNT AS VARCHAR) + ' rows';
GO

-- ── applications.csv ───────────────────────────────────────
-- Columns: ApplicationID,ApplicationName,ProgramID,Platform,IsActive
BULK INSERT stg.Application
FROM 'C:\XrayExports\applications.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR   = '0x0a',
    FIRSTROW        = 2,
    CODEPAGE        = '65001',
    TABLOCK,
    ERRORFILE       = 'C:\XrayExports\errors\applications_err.txt'
);
PRINT 'Loaded stg.Application: ' + CAST(@@ROWCOUNT AS VARCHAR) + ' rows';
GO

-- ── squads.csv ─────────────────────────────────────────────
-- Columns: SquadID,SquadName,ApplicationID,IsActive
BULK INSERT stg.Squad
FROM 'C:\XrayExports\squads.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR   = '0x0a',
    FIRSTROW        = 2,
    CODEPAGE        = '65001',
    TABLOCK,
    ERRORFILE       = 'C:\XrayExports\errors\squads_err.txt'
);
PRINT 'Loaded stg.Squad: ' + CAST(@@ROWCOUNT AS VARCHAR) + ' rows';
GO

-- ── releases.csv ───────────────────────────────────────────
-- Columns: ReleaseID,ReleaseName,ReleaseTrain,PlannedStartDate,
--          PlannedEndDate,GoLiveDate,ActualGoLiveDate,ReleaseStatus,ProgramID
-- Dates  : DD/MM/YYYY or YYYY-MM-DD both accepted
BULK INSERT stg.Release
FROM 'C:\XrayExports\releases.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR   = '0x0a',
    FIRSTROW        = 2,
    CODEPAGE        = '65001',
    TABLOCK,
    ERRORFILE       = 'C:\XrayExports\errors\releases_err.txt'
);
PRINT 'Loaded stg.Release: ' + CAST(@@ROWCOUNT AS VARCHAR) + ' rows';
GO

-- ── environments.csv ───────────────────────────────────────
-- Columns: EnvironmentID,EnvironmentName,EnvironmentType,Platform,Criticality,IsActive
BULK INSERT stg.Environment
FROM 'C:\XrayExports\environments.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR   = '0x0a',
    FIRSTROW        = 2,
    CODEPAGE        = '65001',
    TABLOCK,
    ERRORFILE       = 'C:\XrayExports\errors\environments_err.txt'
);
PRINT 'Loaded stg.Environment: ' + CAST(@@ROWCOUNT AS VARCHAR) + ' rows';
GO

-- ── testers.csv ────────────────────────────────────────────
-- Columns: TesterID,TesterName,Email,TeamName,ManagerName,IsActive
BULK INSERT stg.Tester
FROM 'C:\XrayExports\testers.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR   = '0x0a',
    FIRSTROW        = 2,
    CODEPAGE        = '65001',
    TABLOCK,
    ERRORFILE       = 'C:\XrayExports\errors\testers_err.txt'
);
PRINT 'Loaded stg.Tester: ' + CAST(@@ROWCOUNT AS VARCHAR) + ' rows';
GO

-- ── requirements.csv ───────────────────────────────────────
-- Columns: RequirementID,RequirementName,Priority,BusinessArea,
--          CriticalFlag,ApplicationID,IsActive
BULK INSERT stg.Requirement
FROM 'C:\XrayExports\requirements.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR   = '0x0a',
    FIRSTROW        = 2,
    CODEPAGE        = '65001',
    TABLOCK,
    ERRORFILE       = 'C:\XrayExports\errors\requirements_err.txt'
);
PRINT 'Loaded stg.Requirement: ' + CAST(@@ROWCOUNT AS VARCHAR) + ' rows';
GO

-- ── tests.csv ──────────────────────────────────────────────
-- Columns: TestID,TestName,TestType,AutomationFlag,Component,
--          ApplicationID,Priority,IsActive
BULK INSERT stg.Test
FROM 'C:\XrayExports\tests.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR   = '0x0a',
    FIRSTROW        = 2,
    CODEPAGE        = '65001',
    TABLOCK,
    ERRORFILE       = 'C:\XrayExports\errors\tests_err.txt'
);
PRINT 'Loaded stg.Test: ' + CAST(@@ROWCOUNT AS VARCHAR) + ' rows';
GO

-- ── defects.csv ────────────────────────────────────────────
-- Columns: DefectID,DefectSummary,Severity,Status,AssignedTeam,
--          LeakageFlag,ApplicationID,ReleaseFoundID
BULK INSERT stg.Defect
FROM 'C:\XrayExports\defects.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR   = '0x0a',
    FIRSTROW        = 2,
    CODEPAGE        = '65001',
    TABLOCK,
    ERRORFILE       = 'C:\XrayExports\errors\defects_err.txt'
);
PRINT 'Loaded stg.Defect: ' + CAST(@@ROWCOUNT AS VARCHAR) + ' rows';
GO

-- ── test_runs.csv ──────────────────────────────────────────
-- Source : Xray Cloud: Reports > Test Execution > Export CSV
--          Xray Server: Test Execution issue > Export executions
-- Columns: ExecutionID,TestID,RequirementID,ReleaseID,EnvironmentID,
--          TesterID,StatusName,RootCauseName,ExecutionDate,ApplicationID,
--          SquadID,RunSequence,IsAutomated,DurationMinutes,IsBlocked,
--          BlockReason,LinkedDefectCount,ExecutionSource,Comments
BULK INSERT stg.TestRun
FROM 'C:\XrayExports\test_runs.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR   = '0x0a',
    FIRSTROW        = 2,
    CODEPAGE        = '65001',
    TABLOCK,
    ERRORFILE       = 'C:\XrayExports\errors\test_runs_err.txt'
);
PRINT 'Loaded stg.TestRun: ' + CAST(@@ROWCOUNT AS VARCHAR) + ' rows';
GO

-- ── requirement_coverage.csv ───────────────────────────────
-- Source : Xray Requirement Coverage report > Export
-- Columns: RequirementID,ReleaseID,CoveredFlag,PartialCoverageFlag,
--          FailedCoverageFlag,LinkedTestCount,LatestExecutionDate
BULK INSERT stg.RequirementCoverage
FROM 'C:\XrayExports\requirement_coverage.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR   = '0x0a',
    FIRSTROW        = 2,
    CODEPAGE        = '65001',
    TABLOCK,
    ERRORFILE       = 'C:\XrayExports\errors\req_coverage_err.txt'
);
PRINT 'Loaded stg.RequirementCoverage: ' + CAST(@@ROWCOUNT AS VARCHAR) + ' rows';
GO

-- ── defect_links.csv ───────────────────────────────────────
-- Source : Jira JQL: issueType = Bug AND issueLinks is not EMPTY
-- Columns: DefectID,ExecutionID,RequirementID,ReleaseID,LinkType,OpenFlag
BULK INSERT stg.DefectLink
FROM 'C:\XrayExports\defect_links.csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR   = '0x0a',
    FIRSTROW        = 2,
    CODEPAGE        = '65001',
    TABLOCK,
    ERRORFILE       = 'C:\XrayExports\errors\defect_links_err.txt'
);
PRINT 'Loaded stg.DefectLink: ' + CAST(@@ROWCOUNT AS VARCHAR) + ' rows';
GO

-- ── Row count summary ───────────────────────────────────────
SELECT 'stg.Program'             AS StagingTable, COUNT(*) AS RowsLoaded FROM stg.Program             UNION ALL
SELECT 'stg.Application',                         COUNT(*)               FROM stg.Application         UNION ALL
SELECT 'stg.Squad',                               COUNT(*)               FROM stg.Squad               UNION ALL
SELECT 'stg.Release',                             COUNT(*)               FROM stg.Release             UNION ALL
SELECT 'stg.Environment',                         COUNT(*)               FROM stg.Environment         UNION ALL
SELECT 'stg.Tester',                              COUNT(*)               FROM stg.Tester              UNION ALL
SELECT 'stg.Requirement',                         COUNT(*)               FROM stg.Requirement         UNION ALL
SELECT 'stg.Test',                                COUNT(*)               FROM stg.Test                UNION ALL
SELECT 'stg.Defect',                              COUNT(*)               FROM stg.Defect              UNION ALL
SELECT 'stg.TestRun',                             COUNT(*)               FROM stg.TestRun             UNION ALL
SELECT 'stg.RequirementCoverage',                 COUNT(*)               FROM stg.RequirementCoverage UNION ALL
SELECT 'stg.DefectLink',                          COUNT(*)               FROM stg.DefectLink
ORDER BY StagingTable;
GO

PRINT 'Bulk load complete. Review row counts and error files before proceeding to Step 3.';
GO
