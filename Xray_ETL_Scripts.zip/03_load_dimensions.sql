-- ============================================================
-- Xray ETL Step 3: Load Dimension Tables (MERGE upsert)
-- Pattern : MERGE inserts new rows, updates changed rows
-- Order   : Parents before children (FK hierarchy)
-- ============================================================
USE XrayTestMetrics;
GO

DECLARE @BatchID  UNIQUEIDENTIFIER = NEWID();
DECLARE @Rows     INT;
PRINT 'BatchID: ' + CAST(@BatchID AS VARCHAR(36));

-- ── Helper: convert TRUE/YES/1 → 1, else 0 ─────────────────
-- Inline CASE used throughout below

-- ============================================================
-- 1. DimProgram
-- ============================================================
INSERT stg.ETLLog (BatchID,TableName,StepName)
VALUES (@BatchID,'DimProgram','MERGE Start');

MERGE dbo.DimProgram AS tgt
USING (
    SELECT
        LTRIM(RTRIM(src_ProgramID))     AS ProgramID,
        LTRIM(RTRIM(src_ProgramName))   AS ProgramName,
        LTRIM(RTRIM(src_PortfolioName)) AS PortfolioName,
        CASE UPPER(LTRIM(RTRIM(src_IsActive)))
            WHEN 'TRUE' THEN 1 WHEN 'YES' THEN 1 WHEN '1' THEN 1 ELSE 0 END AS IsActive
    FROM stg.Program
    WHERE LTRIM(RTRIM(ISNULL(src_ProgramID,''))) <> ''
) src ON tgt.ProgramID = src.ProgramID
WHEN MATCHED AND (
    tgt.ProgramName   <> src.ProgramName   OR
    tgt.PortfolioName <> src.PortfolioName OR
    tgt.IsActive      <> src.IsActive
) THEN UPDATE SET
    ProgramName   = src.ProgramName,
    PortfolioName = src.PortfolioName,
    IsActive      = src.IsActive,
    ModifiedDate  = SYSUTCDATETIME()
WHEN NOT MATCHED BY TARGET THEN
    INSERT (ProgramID, ProgramName, PortfolioName, IsActive)
    VALUES (src.ProgramID, src.ProgramName, src.PortfolioName, src.IsActive);

SET @Rows = @@ROWCOUNT;
UPDATE stg.ETLLog SET EndTime=SYSUTCDATETIME(),Status='Success',RowsInserted=@Rows
WHERE BatchID=@BatchID AND TableName='DimProgram';
PRINT 'DimProgram: ' + CAST(@Rows AS VARCHAR) + ' rows merged.';

-- ============================================================
-- 2. DimApplication
-- ============================================================
INSERT stg.ETLLog (BatchID,TableName,StepName)
VALUES (@BatchID,'DimApplication','MERGE Start');

MERGE dbo.DimApplication AS tgt
USING (
    SELECT
        LTRIM(RTRIM(s.src_ApplicationID))   AS ApplicationID,
        LTRIM(RTRIM(s.src_ApplicationName)) AS ApplicationName,
        p.ProgramKey,
        NULLIF(LTRIM(RTRIM(s.src_Platform)),'')  AS Platform,
        CASE UPPER(LTRIM(RTRIM(s.src_IsActive)))
            WHEN 'TRUE' THEN 1 WHEN 'YES' THEN 1 WHEN '1' THEN 1 ELSE 0 END AS IsActive
    FROM stg.Application s
    JOIN dbo.DimProgram p ON p.ProgramID = LTRIM(RTRIM(s.src_ProgramID))
    WHERE LTRIM(RTRIM(ISNULL(s.src_ApplicationID,''))) <> ''
) src ON tgt.ApplicationID = src.ApplicationID
WHEN MATCHED AND (
    tgt.ApplicationName <> src.ApplicationName OR
    tgt.ProgramKey      <> src.ProgramKey      OR
    ISNULL(tgt.Platform,'') <> ISNULL(src.Platform,'') OR
    tgt.IsActive        <> src.IsActive
) THEN UPDATE SET
    ApplicationName = src.ApplicationName,
    ProgramKey      = src.ProgramKey,
    Platform        = src.Platform,
    IsActive        = src.IsActive,
    ModifiedDate    = SYSUTCDATETIME()
WHEN NOT MATCHED BY TARGET THEN
    INSERT (ApplicationID, ApplicationName, ProgramKey, Platform, IsActive)
    VALUES (src.ApplicationID, src.ApplicationName, src.ProgramKey, src.Platform, src.IsActive);

SET @Rows = @@ROWCOUNT;
UPDATE stg.ETLLog SET EndTime=SYSUTCDATETIME(),Status='Success',RowsInserted=@Rows
WHERE BatchID=@BatchID AND TableName='DimApplication';
PRINT 'DimApplication: ' + CAST(@Rows AS VARCHAR) + ' rows merged.';

-- ============================================================
-- 3. DimSquad
-- ============================================================
INSERT stg.ETLLog (BatchID,TableName,StepName)
VALUES (@BatchID,'DimSquad','MERGE Start');

MERGE dbo.DimSquad AS tgt
USING (
    SELECT
        LTRIM(RTRIM(s.src_SquadID))   AS SquadID,
        LTRIM(RTRIM(s.src_SquadName)) AS SquadName,
        a.ApplicationKey,
        CASE UPPER(LTRIM(RTRIM(s.src_IsActive)))
            WHEN 'TRUE' THEN 1 WHEN 'YES' THEN 1 WHEN '1' THEN 1 ELSE 0 END AS IsActive
    FROM stg.Squad s
    JOIN dbo.DimApplication a ON a.ApplicationID = LTRIM(RTRIM(s.src_ApplicationID))
    WHERE LTRIM(RTRIM(ISNULL(s.src_SquadID,''))) <> ''
) src ON tgt.SquadID = src.SquadID
WHEN MATCHED AND (
    tgt.SquadName      <> src.SquadName      OR
    tgt.ApplicationKey <> src.ApplicationKey OR
    tgt.IsActive       <> src.IsActive
) THEN UPDATE SET
    SquadName      = src.SquadName,
    ApplicationKey = src.ApplicationKey,
    IsActive       = src.IsActive,
    ModifiedDate   = SYSUTCDATETIME()
WHEN NOT MATCHED BY TARGET THEN
    INSERT (SquadID, SquadName, ApplicationKey, IsActive)
    VALUES (src.SquadID, src.SquadName, src.ApplicationKey, src.IsActive);

SET @Rows = @@ROWCOUNT;
UPDATE stg.ETLLog SET EndTime=SYSUTCDATETIME(),Status='Success',RowsInserted=@Rows
WHERE BatchID=@BatchID AND TableName='DimSquad';
PRINT 'DimSquad: ' + CAST(@Rows AS VARCHAR) + ' rows merged.';

-- ============================================================
-- 4. DimRelease
-- ============================================================
INSERT stg.ETLLog (BatchID,TableName,StepName)
VALUES (@BatchID,'DimRelease','MERGE Start');

MERGE dbo.DimRelease AS tgt
USING (
    SELECT
        LTRIM(RTRIM(s.src_ReleaseID))    AS ReleaseID,
        LTRIM(RTRIM(s.src_ReleaseName))  AS ReleaseName,
        NULLIF(LTRIM(RTRIM(s.src_ReleaseTrain)),'') AS ReleaseTrain,
        TRY_CAST(s.src_PlannedStartDate  AS DATE) AS PlannedStartDate,
        TRY_CAST(s.src_PlannedEndDate    AS DATE) AS PlannedEndDate,
        TRY_CAST(s.src_GoLiveDate        AS DATE) AS GoLiveDate,
        TRY_CAST(s.src_ActualGoLiveDate  AS DATE) AS ActualGoLiveDate,
        CASE UPPER(LTRIM(RTRIM(s.src_ReleaseStatus)))
            WHEN 'PLANNING'     THEN 'Planning'
            WHEN 'IN PROGRESS'  THEN 'In Progress'
            WHEN 'RELEASED'     THEN 'Released'
            WHEN 'ON HOLD'      THEN 'On Hold'
            WHEN 'CANCELLED'    THEN 'Cancelled'
            ELSE 'Planning'
        END AS ReleaseStatus,
        p.ProgramKey
    FROM stg.Release s
    LEFT JOIN dbo.DimProgram p ON p.ProgramID = LTRIM(RTRIM(s.src_ProgramID))
    WHERE LTRIM(RTRIM(ISNULL(s.src_ReleaseID,''))) <> ''
) src ON tgt.ReleaseID = src.ReleaseID
WHEN MATCHED AND (
    tgt.ReleaseName   <> src.ReleaseName   OR
    tgt.ReleaseStatus <> src.ReleaseStatus OR
    ISNULL(CAST(tgt.GoLiveDate AS VARCHAR),'') <>
        ISNULL(CAST(src.GoLiveDate AS VARCHAR),'') OR
    ISNULL(CAST(tgt.ActualGoLiveDate AS VARCHAR),'') <>
        ISNULL(CAST(src.ActualGoLiveDate AS VARCHAR),'')
) THEN UPDATE SET
    ReleaseName      = src.ReleaseName,
    ReleaseTrain     = src.ReleaseTrain,
    PlannedStartDate = src.PlannedStartDate,
    PlannedEndDate   = src.PlannedEndDate,
    GoLiveDate       = src.GoLiveDate,
    ActualGoLiveDate = src.ActualGoLiveDate,
    ReleaseStatus    = src.ReleaseStatus,
    ProgramKey       = src.ProgramKey,
    ModifiedDate     = SYSUTCDATETIME()
WHEN NOT MATCHED BY TARGET THEN
    INSERT (ReleaseID,ReleaseName,ReleaseTrain,PlannedStartDate,PlannedEndDate,
            GoLiveDate,ActualGoLiveDate,ReleaseStatus,ProgramKey)
    VALUES (src.ReleaseID,src.ReleaseName,src.ReleaseTrain,src.PlannedStartDate,
            src.PlannedEndDate,src.GoLiveDate,src.ActualGoLiveDate,
            src.ReleaseStatus,src.ProgramKey);

SET @Rows = @@ROWCOUNT;
UPDATE stg.ETLLog SET EndTime=SYSUTCDATETIME(),Status='Success',RowsInserted=@Rows
WHERE BatchID=@BatchID AND TableName='DimRelease';
PRINT 'DimRelease: ' + CAST(@Rows AS VARCHAR) + ' rows merged.';

-- ============================================================
-- 5. DimEnvironment
-- ============================================================
INSERT stg.ETLLog (BatchID,TableName,StepName)
VALUES (@BatchID,'DimEnvironment','MERGE Start');

MERGE dbo.DimEnvironment AS tgt
USING (
    SELECT
        LTRIM(RTRIM(src_EnvironmentID))   AS EnvironmentID,
        LTRIM(RTRIM(src_EnvironmentName)) AS EnvironmentName,
        CASE UPPER(LTRIM(RTRIM(src_EnvironmentType)))
            WHEN 'DEV'         THEN 'Development'
            WHEN 'DEVELOPMENT' THEN 'Development'
            WHEN 'SIT'         THEN 'Integration'
            WHEN 'INTEGRATION' THEN 'Integration'
            WHEN 'UAT'         THEN 'Acceptance'
            WHEN 'ACCEPTANCE'  THEN 'Acceptance'
            WHEN 'PROD'        THEN 'Production'
            WHEN 'PRODUCTION'  THEN 'Production'
            WHEN 'PERF'        THEN 'Performance'
            WHEN 'PERFORMANCE' THEN 'Performance'
            ELSE 'Sandbox'
        END AS EnvironmentType,
        NULLIF(LTRIM(RTRIM(src_Platform)),'') AS Platform,
        CASE UPPER(LTRIM(RTRIM(src_Criticality)))
            WHEN 'HIGH'   THEN 'High'
            WHEN 'MEDIUM' THEN 'Medium'
            ELSE 'Low'
        END AS Criticality,
        CASE UPPER(LTRIM(RTRIM(src_IsActive)))
            WHEN 'TRUE' THEN 1 WHEN 'YES' THEN 1 WHEN '1' THEN 1 ELSE 0 END AS IsActive
    FROM stg.Environment
    WHERE LTRIM(RTRIM(ISNULL(src_EnvironmentID,''))) <> ''
) src ON tgt.EnvironmentID = src.EnvironmentID
WHEN MATCHED AND (
    tgt.EnvironmentName <> src.EnvironmentName OR
    tgt.EnvironmentType <> src.EnvironmentType OR
    tgt.Criticality     <> src.Criticality
) THEN UPDATE SET
    EnvironmentName = src.EnvironmentName,
    EnvironmentType = src.EnvironmentType,
    Platform        = src.Platform,
    Criticality     = src.Criticality,
    IsActive        = src.IsActive,
    ModifiedDate    = SYSUTCDATETIME()
WHEN NOT MATCHED BY TARGET THEN
    INSERT (EnvironmentID,EnvironmentName,EnvironmentType,Platform,Criticality,IsActive)
    VALUES (src.EnvironmentID,src.EnvironmentName,src.EnvironmentType,
            src.Platform,src.Criticality,src.IsActive);

SET @Rows = @@ROWCOUNT;
UPDATE stg.ETLLog SET EndTime=SYSUTCDATETIME(),Status='Success',RowsInserted=@Rows
WHERE BatchID=@BatchID AND TableName='DimEnvironment';
PRINT 'DimEnvironment: ' + CAST(@Rows AS VARCHAR) + ' rows merged.';

-- ============================================================
-- 6. DimTester
-- ============================================================
INSERT stg.ETLLog (BatchID,TableName,StepName)
VALUES (@BatchID,'DimTester','MERGE Start');

MERGE dbo.DimTester AS tgt
USING (
    SELECT
        LTRIM(RTRIM(src_TesterID))    AS TesterID,
        LTRIM(RTRIM(src_TesterName))  AS TesterName,
        NULLIF(LTRIM(RTRIM(src_Email)),'')       AS Email,
        NULLIF(LTRIM(RTRIM(src_TeamName)),'')    AS TeamName,
        NULLIF(LTRIM(RTRIM(src_ManagerName)),'') AS ManagerName,
        CASE UPPER(LTRIM(RTRIM(src_IsActive)))
            WHEN 'TRUE' THEN 1 WHEN 'YES' THEN 1 WHEN '1' THEN 1 ELSE 0 END AS IsActive
    FROM stg.Tester
    WHERE LTRIM(RTRIM(ISNULL(src_TesterID,''))) <> ''
) src ON tgt.TesterID = src.TesterID
WHEN MATCHED AND (
    tgt.TesterName <> src.TesterName OR
    ISNULL(tgt.Email,'') <> ISNULL(src.Email,'')
) THEN UPDATE SET
    TesterName   = src.TesterName,
    Email        = src.Email,
    TeamName     = src.TeamName,
    ManagerName  = src.ManagerName,
    IsActive     = src.IsActive,
    ModifiedDate = SYSUTCDATETIME()
WHEN NOT MATCHED BY TARGET THEN
    INSERT (TesterID,TesterName,Email,TeamName,ManagerName,IsActive)
    VALUES (src.TesterID,src.TesterName,src.Email,src.TeamName,src.ManagerName,src.IsActive);

SET @Rows = @@ROWCOUNT;
UPDATE stg.ETLLog SET EndTime=SYSUTCDATETIME(),Status='Success',RowsInserted=@Rows
WHERE BatchID=@BatchID AND TableName='DimTester';
PRINT 'DimTester: ' + CAST(@Rows AS VARCHAR) + ' rows merged.';

-- ============================================================
-- 7. DimRequirement
-- ============================================================
INSERT stg.ETLLog (BatchID,TableName,StepName)
VALUES (@BatchID,'DimRequirement','MERGE Start');

MERGE dbo.DimRequirement AS tgt
USING (
    SELECT
        LTRIM(RTRIM(s.src_RequirementID))   AS RequirementID,
        LTRIM(RTRIM(s.src_RequirementName)) AS RequirementName,
        CASE UPPER(LTRIM(RTRIM(s.src_Priority)))
            WHEN 'CRITICAL' THEN 'Critical'
            WHEN 'HIGH'     THEN 'High'
            WHEN 'MEDIUM'   THEN 'Medium'
            ELSE 'Low'
        END AS Priority,
        NULLIF(LTRIM(RTRIM(s.src_BusinessArea)),'') AS BusinessArea,
        CASE UPPER(LTRIM(RTRIM(s.src_CriticalFlag)))
            WHEN 'TRUE' THEN 1 WHEN 'YES' THEN 1 WHEN '1' THEN 1 ELSE 0 END AS CriticalFlag,
        a.ApplicationKey,
        CASE UPPER(LTRIM(RTRIM(s.src_IsActive)))
            WHEN 'TRUE' THEN 1 WHEN 'YES' THEN 1 WHEN '1' THEN 1 ELSE 0 END AS IsActive
    FROM stg.Requirement s
    LEFT JOIN dbo.DimApplication a ON a.ApplicationID = LTRIM(RTRIM(s.src_ApplicationID))
    WHERE LTRIM(RTRIM(ISNULL(s.src_RequirementID,''))) <> ''
) src ON tgt.RequirementID = src.RequirementID
WHEN MATCHED AND (
    tgt.RequirementName <> src.RequirementName OR
    tgt.Priority        <> src.Priority        OR
    tgt.CriticalFlag    <> src.CriticalFlag
) THEN UPDATE SET
    RequirementName = src.RequirementName,
    Priority        = src.Priority,
    BusinessArea    = src.BusinessArea,
    CriticalFlag    = src.CriticalFlag,
    ApplicationKey  = src.ApplicationKey,
    IsActive        = src.IsActive,
    ModifiedDate    = SYSUTCDATETIME()
WHEN NOT MATCHED BY TARGET THEN
    INSERT (RequirementID,RequirementName,Priority,BusinessArea,
            CriticalFlag,ApplicationKey,IsActive)
    VALUES (src.RequirementID,src.RequirementName,src.Priority,src.BusinessArea,
            src.CriticalFlag,src.ApplicationKey,src.IsActive);

SET @Rows = @@ROWCOUNT;
UPDATE stg.ETLLog SET EndTime=SYSUTCDATETIME(),Status='Success',RowsInserted=@Rows
WHERE BatchID=@BatchID AND TableName='DimRequirement';
PRINT 'DimRequirement: ' + CAST(@Rows AS VARCHAR) + ' rows merged.';

-- ============================================================
-- 8. DimTest
-- ============================================================
INSERT stg.ETLLog (BatchID,TableName,StepName)
VALUES (@BatchID,'DimTest','MERGE Start');

MERGE dbo.DimTest AS tgt
USING (
    SELECT
        LTRIM(RTRIM(s.src_TestID))   AS TestID,
        LTRIM(RTRIM(s.src_TestName)) AS TestName,
        CASE UPPER(LTRIM(RTRIM(s.src_TestType)))
            WHEN 'FUNCTIONAL'  THEN 'Functional'
            WHEN 'REGRESSION'  THEN 'Regression'
            WHEN 'SMOKE'       THEN 'Smoke'
            WHEN 'PERFORMANCE' THEN 'Performance'
            WHEN 'INTEGRATION' THEN 'Integration'
            WHEN 'SECURITY'    THEN 'Security'
            WHEN 'UAT'         THEN 'UAT'
            ELSE 'Exploratory'
        END AS TestType,
        CASE UPPER(LTRIM(RTRIM(s.src_AutomationFlag)))
            WHEN 'TRUE' THEN 1 WHEN 'YES' THEN 1 WHEN '1' THEN 1 ELSE 0 END AS AutomationFlag,
        NULLIF(LTRIM(RTRIM(s.src_Component)),'') AS Component,
        a.ApplicationKey,
        NULLIF(LTRIM(RTRIM(s.src_Priority)),'')  AS Priority,
        CASE UPPER(LTRIM(RTRIM(s.src_IsActive)))
            WHEN 'TRUE' THEN 1 WHEN 'YES' THEN 1 WHEN '1' THEN 1 ELSE 0 END AS IsActive
    FROM stg.Test s
    LEFT JOIN dbo.DimApplication a ON a.ApplicationID = LTRIM(RTRIM(s.src_ApplicationID))
    WHERE LTRIM(RTRIM(ISNULL(s.src_TestID,''))) <> ''
) src ON tgt.TestID = src.TestID
WHEN MATCHED AND (
    tgt.TestName       <> src.TestName       OR
    tgt.AutomationFlag <> src.AutomationFlag OR
    tgt.IsActive       <> src.IsActive
) THEN UPDATE SET
    TestName       = src.TestName,
    TestType       = src.TestType,
    AutomationFlag = src.AutomationFlag,
    Component      = src.Component,
    ApplicationKey = src.ApplicationKey,
    Priority       = src.Priority,
    IsActive       = src.IsActive,
    ModifiedDate   = SYSUTCDATETIME()
WHEN NOT MATCHED BY TARGET THEN
    INSERT (TestID,TestName,TestType,AutomationFlag,Component,ApplicationKey,Priority,IsActive)
    VALUES (src.TestID,src.TestName,src.TestType,src.AutomationFlag,
            src.Component,src.ApplicationKey,src.Priority,src.IsActive);

SET @Rows = @@ROWCOUNT;
UPDATE stg.ETLLog SET EndTime=SYSUTCDATETIME(),Status='Success',RowsInserted=@Rows
WHERE BatchID=@BatchID AND TableName='DimTest';
PRINT 'DimTest: ' + CAST(@Rows AS VARCHAR) + ' rows merged.';

-- ============================================================
-- 9. DimDefect
-- ============================================================
INSERT stg.ETLLog (BatchID,TableName,StepName)
VALUES (@BatchID,'DimDefect','MERGE Start');

MERGE dbo.DimDefect AS tgt
USING (
    SELECT
        LTRIM(RTRIM(s.src_DefectID))      AS DefectID,
        NULLIF(LTRIM(RTRIM(s.src_DefectSummary)),'') AS DefectSummary,
        CASE UPPER(LTRIM(RTRIM(s.src_Severity)))
            WHEN 'CRITICAL' THEN 'Critical'
            WHEN 'SEV1'     THEN 'Sev1'
            WHEN 'HIGH'     THEN 'High'
            WHEN 'SEV2'     THEN 'Sev2'
            WHEN 'MEDIUM'   THEN 'Medium'
            WHEN 'SEV3'     THEN 'Sev3'
            WHEN 'LOW'      THEN 'Low'
            ELSE 'Sev4'
        END AS Severity,
        CASE UPPER(LTRIM(RTRIM(s.src_Status)))
            WHEN 'OPEN'        THEN 'Open'
            WHEN 'IN PROGRESS' THEN 'In Progress'
            WHEN 'RESOLVED'    THEN 'Resolved'
            WHEN 'CLOSED'      THEN 'Closed'
            WHEN 'REOPENED'    THEN 'Reopened'
            ELSE 'Deferred'
        END AS DefectStatus,
        NULLIF(LTRIM(RTRIM(s.src_AssignedTeam)),'') AS AssignedTeam,
        CASE UPPER(LTRIM(RTRIM(s.src_LeakageFlag)))
            WHEN 'TRUE' THEN 1 WHEN 'YES' THEN 1 WHEN '1' THEN 1 ELSE 0 END AS LeakageFlag,
        a.ApplicationKey,
        r.ReleaseKey AS ReleaseFoundKey
    FROM stg.Defect s
    LEFT JOIN dbo.DimApplication a ON a.ApplicationID = LTRIM(RTRIM(s.src_ApplicationID))
    LEFT JOIN dbo.DimRelease     r ON r.ReleaseID     = LTRIM(RTRIM(s.src_ReleaseFoundID))
    WHERE LTRIM(RTRIM(ISNULL(s.src_DefectID,''))) <> ''
) src ON tgt.DefectID = src.DefectID
WHEN MATCHED AND (
    tgt.Status   <> src.DefectStatus OR
    tgt.Severity <> src.Severity
) THEN UPDATE SET
    DefectSummary   = src.DefectSummary,
    Severity        = src.Severity,
    Status          = src.DefectStatus,
    AssignedTeam    = src.AssignedTeam,
    LeakageFlag     = src.LeakageFlag,
    ApplicationKey  = src.ApplicationKey,
    ReleaseFoundKey = src.ReleaseFoundKey,
    ModifiedDate    = SYSUTCDATETIME()
WHEN NOT MATCHED BY TARGET THEN
    INSERT (DefectID,DefectSummary,Severity,Status,AssignedTeam,
            LeakageFlag,ApplicationKey,ReleaseFoundKey)
    VALUES (src.DefectID,src.DefectSummary,src.Severity,src.DefectStatus,
            src.AssignedTeam,src.LeakageFlag,src.ApplicationKey,src.ReleaseFoundKey);

SET @Rows = @@ROWCOUNT;
UPDATE stg.ETLLog SET EndTime=SYSUTCDATETIME(),Status='Success',RowsInserted=@Rows
WHERE BatchID=@BatchID AND TableName='DimDefect';
PRINT 'DimDefect: ' + CAST(@Rows AS VARCHAR) + ' rows merged.';

PRINT 'All dimensions loaded. Proceed to Step 4 (load facts).';
GO
