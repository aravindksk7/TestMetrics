-- ============================================================
-- Xray ETL Step 5: Populate DimDate
-- Run once to seed; re-run to extend the date range
-- Generates one row per calendar day between @StartDate and @EndDate
-- ============================================================
USE XrayTestMetrics;
GO

DECLARE @StartDate   DATE = '2023-01-01';   -- ← Extend as needed
DECLARE @EndDate     DATE = '2027-12-31';
DECLARE @CurrentDate DATE = @StartDate;
DECLARE @SprintNum   INT;

TRUNCATE TABLE dbo.DimDate;

WHILE @CurrentDate <= @EndDate
BEGIN
    SET @SprintNum = CEILING(CAST(DATEDIFF(DAY, @StartDate, @CurrentDate) + 1 AS FLOAT) / 14);

    INSERT INTO dbo.DimDate (
        DateKey, FullDate, DayOfMonth, DayOfWeek, DayName,
        WeekOfYear, Month, MonthName, Quarter, Year,
        FinancialYear, Sprint, IsWeekend, IsPublicHoliday
    ) VALUES (
        CAST(FORMAT(@CurrentDate, 'yyyyMMdd') AS INT),
        @CurrentDate,
        DAY(@CurrentDate),
        DATEPART(WEEKDAY, @CurrentDate),
        DATENAME(WEEKDAY, @CurrentDate),
        DATEPART(ISO_WEEK, @CurrentDate),
        MONTH(@CurrentDate),
        DATENAME(MONTH, @CurrentDate),
        DATEPART(QUARTER, @CurrentDate),
        YEAR(@CurrentDate),
        'FY' + CAST(YEAR(@CurrentDate) AS CHAR(4)),
        'Sprint ' + CAST(@SprintNum AS VARCHAR(5)),
        CASE WHEN DATEPART(WEEKDAY, @CurrentDate) IN (1,7) THEN 1 ELSE 0 END,
        0   -- Update public holidays manually or via a holiday reference table
    );

    SET @CurrentDate = DATEADD(DAY, 1, @CurrentDate);
END;

-- Verification
SELECT
    COUNT(*)             AS TotalDays,
    MIN(FullDate)        AS FirstDate,
    MAX(FullDate)        AS LastDate,
    COUNT(DISTINCT Year) AS YearsCovered,
    COUNT(DISTINCT Sprint) AS TotalSprints,
    SUM(IsWeekend)       AS WeekendDays
FROM dbo.DimDate;
GO

PRINT 'DimDate populated successfully.';
GO
