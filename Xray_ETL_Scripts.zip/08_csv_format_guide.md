# Xray ETL — CSV Export Format Guide

## How to export from Jira / Xray

| File | Source in Jira / Xray | Export path |
|---|---|---|
| `programs.csv` | Manual / project register | Manual extract or Admin > Projects |
| `applications.csv` | Jira Components or custom field | Project Settings > Components |
| `squads.csv` | Jira Team field | Custom field report |
| `releases.csv` | Jira Versions | Project Settings > Versions > Export |
| `environments.csv` | Xray environments config | Xray > Settings > Environments |
| `testers.csv` | Jira Users | Admin > User Management > Export |
| `requirements.csv` | Jira issues (Story/Requirement) | Issues > Export > All fields |
| `tests.csv` | Xray Test issues | Xray > Test Repository > Export |
| `defects.csv` | Jira Bug issues | Issues > Export > All fields |
| `test_runs.csv` | Xray executions | Xray > Reports > Test Execution > CSV |
| `requirement_coverage.csv` | Xray coverage report | Xray > Reports > Requirement Coverage > CSV |
| `defect_links.csv` | Jira issue links | JQL: `issueType = Bug AND issueLinks is not EMPTY` |

---

## Required CSV column headers (exact match)

### programs.csv
```
ProgramID,ProgramName,PortfolioName,IsActive
PROG-001,Payments Program,Financial Portfolio,TRUE
```

### applications.csv
```
ApplicationID,ApplicationName,ProgramID,Platform,IsActive
APP-001,Payments API,PROG-001,API,TRUE
```

### squads.csv
```
SquadID,SquadName,ApplicationID,IsActive
SQ-001,Squad Alpha,APP-001,TRUE
```

### releases.csv
```
ReleaseID,ReleaseName,ReleaseTrain,PlannedStartDate,PlannedEndDate,GoLiveDate,ActualGoLiveDate,ReleaseStatus,ProgramID
REL-001,R1.0,Train A,01/01/2024,31/03/2024,05/04/2024,,Released,PROG-001
```

### environments.csv
```
EnvironmentID,EnvironmentName,EnvironmentType,Platform,Criticality,IsActive
ENV-001,UAT-APAC,UAT,AWS,High,TRUE
```

### testers.csv
```
TesterID,TesterName,Email,TeamName,ManagerName,IsActive
jsmith,John Smith,john.smith@company.com,QA Team,Jane Manager,TRUE
```

### requirements.csv
```
RequirementID,RequirementName,Priority,BusinessArea,CriticalFlag,ApplicationID,IsActive
REQ-1001,User can log in with MFA,Critical,Security,TRUE,APP-001,TRUE
```

### tests.csv
```
TestID,TestName,TestType,AutomationFlag,Component,ApplicationID,Priority,IsActive
TEST-2001,Verify MFA login flow,Functional,TRUE,Login,APP-001,High,TRUE
```

### defects.csv
```
DefectID,DefectSummary,Severity,Status,AssignedTeam,LeakageFlag,ApplicationID,ReleaseFoundID
BUG-3001,Login fails on Safari,Critical,Open,Squad Alpha,FALSE,APP-001,REL-001
```

### test_runs.csv
```
ExecutionID,TestID,RequirementID,ReleaseID,EnvironmentID,TesterID,StatusName,RootCauseName,ExecutionDate,ApplicationID,SquadID,RunSequence,IsAutomated,DurationMinutes,IsBlocked,BlockReason,LinkedDefectCount,ExecutionSource,Comments
EXEC-9001,TEST-2001,REQ-1001,REL-001,ENV-001,jsmith,PASSED,Not Applicable,2024-03-15,APP-001,SQ-001,1,TRUE,2.5,FALSE,,0,CI/CD,
```

### requirement_coverage.csv
```
RequirementID,ReleaseID,CoveredFlag,PartialCoverageFlag,FailedCoverageFlag,LinkedTestCount,LatestExecutionDate
REQ-1001,REL-001,TRUE,FALSE,FALSE,3,2024-03-15
```

### defect_links.csv
```
DefectID,ExecutionID,RequirementID,ReleaseID,LinkType,OpenFlag
BUG-3001,EXEC-9001,REQ-1001,REL-001,Caused By,TRUE
```

---

## Rules

- All files must be **UTF-8** encoded (Excel: Save As > CSV UTF-8)
- First row is always the **header row** (`FIRSTROW=2` in BULK INSERT)
- Fields containing commas must be wrapped in `"double quotes"`
- **Dates**: DD/MM/YYYY, YYYY-MM-DD, or MM/DD/YYYY all accepted
- **Boolean**: TRUE/FALSE, YES/NO, 1/0 all accepted
- **Empty optional fields**: leave blank — do not write NULL or "NULL"
- **StatusName** in test_runs.csv must exactly match: `PASSED`, `FAILED`, `BLOCKED`, `IN PROGRESS`, `NOT RUN`, `SKIP`
- **RootCauseName** must exactly match a value in `DimRootCause.RootCauseName`
- Error files are written to `C:\XrayExports\errors\` — always check after bulk load

---

## Execution order

```
05_generate_dimdate.sql    ← Run once (or to extend date range)
01_staging_tables.sql      ← Run once to create stg schema
02_bulk_load.sql           ← Run each cycle after CSV export
03_load_dimensions.sql     ← Run each cycle
04_load_facts.sql          ← Run each cycle
06_data_quality.sql        ← Run each cycle — fix any FAIL rows
```
