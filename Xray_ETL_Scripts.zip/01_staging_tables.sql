-- ============================================================
-- Xray ETL Step 1: Create Staging Tables
-- Purpose : Land raw CSV data before transformation
-- Run     : Once to create; truncated each load cycle
-- ============================================================
USE XrayTestMetrics;
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'stg')
    EXEC ('CREATE SCHEMA stg');
GO

IF OBJECT_ID('stg.TestRun',             'U') IS NOT NULL DROP TABLE stg.TestRun;
IF OBJECT_ID('stg.RequirementCoverage', 'U') IS NOT NULL DROP TABLE stg.RequirementCoverage;
IF OBJECT_ID('stg.DefectLink',          'U') IS NOT NULL DROP TABLE stg.DefectLink;
IF OBJECT_ID('stg.Test',                'U') IS NOT NULL DROP TABLE stg.Test;
IF OBJECT_ID('stg.Requirement',         'U') IS NOT NULL DROP TABLE stg.Requirement;
IF OBJECT_ID('stg.Defect',              'U') IS NOT NULL DROP TABLE stg.Defect;
IF OBJECT_ID('stg.Release',             'U') IS NOT NULL DROP TABLE stg.Release;
IF OBJECT_ID('stg.Environment',         'U') IS NOT NULL DROP TABLE stg.Environment;
IF OBJECT_ID('stg.Tester',              'U') IS NOT NULL DROP TABLE stg.Tester;
IF OBJECT_ID('stg.Program',             'U') IS NOT NULL DROP TABLE stg.Program;
IF OBJECT_ID('stg.Application',         'U') IS NOT NULL DROP TABLE stg.Application;
IF OBJECT_ID('stg.Squad',               'U') IS NOT NULL DROP TABLE stg.Squad;
IF OBJECT_ID('stg.ETLLog',              'U') IS NOT NULL DROP TABLE stg.ETLLog;
GO

-- ── ETL audit log ──────────────────────────────────────────
CREATE TABLE stg.ETLLog (
    LogID           INT              NOT NULL IDENTITY(1,1) PRIMARY KEY,
    BatchID         UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID(),
    TableName       VARCHAR(100)     NOT NULL,
    StepName        VARCHAR(100)     NOT NULL,
    RowsSource      INT              NULL,
    RowsInserted    INT              NULL,
    RowsUpdated     INT              NULL,
    RowsRejected    INT              NULL,
    StartTime       DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME(),
    EndTime         DATETIME2        NULL,
    Status          VARCHAR(20)      NOT NULL DEFAULT 'Running'
                        CONSTRAINT CHK_ETLLog_Status
                        CHECK (Status IN ('Running','Success','Failed')),
    ErrorMessage    NVARCHAR(MAX)    NULL
);
GO

-- ── stg.Program ────────────────────────────────────────────
CREATE TABLE stg.Program (
    src_ProgramID       VARCHAR(50)   NULL,
    src_ProgramName     VARCHAR(200)  NULL,
    src_PortfolioName   VARCHAR(200)  NULL,
    src_IsActive        VARCHAR(10)   NULL,
    _LoadedAt           DATETIME2     NOT NULL DEFAULT SYSUTCDATETIME(),
    _RowStatus          VARCHAR(20)   NOT NULL DEFAULT 'Pending'
);
GO

-- ── stg.Application ────────────────────────────────────────
CREATE TABLE stg.Application (
    src_ApplicationID   VARCHAR(50)   NULL,
    src_ApplicationName VARCHAR(200)  NULL,
    src_ProgramID       VARCHAR(50)   NULL,
    src_Platform        VARCHAR(100)  NULL,
    src_IsActive        VARCHAR(10)   NULL,
    _LoadedAt           DATETIME2     NOT NULL DEFAULT SYSUTCDATETIME(),
    _RowStatus          VARCHAR(20)   NOT NULL DEFAULT 'Pending'
);
GO

-- ── stg.Squad ──────────────────────────────────────────────
CREATE TABLE stg.Squad (
    src_SquadID         VARCHAR(50)   NULL,
    src_SquadName       VARCHAR(200)  NULL,
    src_ApplicationID   VARCHAR(50)   NULL,
    src_IsActive        VARCHAR(10)   NULL,
    _LoadedAt           DATETIME2     NOT NULL DEFAULT SYSUTCDATETIME(),
    _RowStatus          VARCHAR(20)   NOT NULL DEFAULT 'Pending'
);
GO

-- ── stg.Release ────────────────────────────────────────────
CREATE TABLE stg.Release (
    src_ReleaseID           VARCHAR(50)   NULL,
    src_ReleaseName         VARCHAR(200)  NULL,
    src_ReleaseTrain        VARCHAR(100)  NULL,
    src_PlannedStartDate    VARCHAR(30)   NULL,
    src_PlannedEndDate      VARCHAR(30)   NULL,
    src_GoLiveDate          VARCHAR(30)   NULL,
    src_ActualGoLiveDate    VARCHAR(30)   NULL,
    src_ReleaseStatus       VARCHAR(50)   NULL,
    src_ProgramID           VARCHAR(50)   NULL,
    _LoadedAt               DATETIME2     NOT NULL DEFAULT SYSUTCDATETIME(),
    _RowStatus              VARCHAR(20)   NOT NULL DEFAULT 'Pending'
);
GO

-- ── stg.Environment ────────────────────────────────────────
CREATE TABLE stg.Environment (
    src_EnvironmentID   VARCHAR(50)   NULL,
    src_EnvironmentName VARCHAR(200)  NULL,
    src_EnvironmentType VARCHAR(100)  NULL,
    src_Platform        VARCHAR(100)  NULL,
    src_Criticality     VARCHAR(20)   NULL,
    src_IsActive        VARCHAR(10)   NULL,
    _LoadedAt           DATETIME2     NOT NULL DEFAULT SYSUTCDATETIME(),
    _RowStatus          VARCHAR(20)   NOT NULL DEFAULT 'Pending'
);
GO

-- ── stg.Tester ─────────────────────────────────────────────
CREATE TABLE stg.Tester (
    src_TesterID        VARCHAR(100)  NULL,
    src_TesterName      VARCHAR(200)  NULL,
    src_Email           VARCHAR(200)  NULL,
    src_TeamName        VARCHAR(100)  NULL,
    src_ManagerName     VARCHAR(200)  NULL,
    src_IsActive        VARCHAR(10)   NULL,
    _LoadedAt           DATETIME2     NOT NULL DEFAULT SYSUTCDATETIME(),
    _RowStatus          VARCHAR(20)   NOT NULL DEFAULT 'Pending'
);
GO

-- ── stg.Requirement ────────────────────────────────────────
CREATE TABLE stg.Requirement (
    src_RequirementID   VARCHAR(50)   NULL,
    src_RequirementName VARCHAR(500)  NULL,
    src_Priority        VARCHAR(50)   NULL,
    src_BusinessArea    VARCHAR(100)  NULL,
    src_CriticalFlag    VARCHAR(10)   NULL,
    src_ApplicationID   VARCHAR(50)   NULL,
    src_IsActive        VARCHAR(10)   NULL,
    _LoadedAt           DATETIME2     NOT NULL DEFAULT SYSUTCDATETIME(),
    _RowStatus          VARCHAR(20)   NOT NULL DEFAULT 'Pending'
);
GO

-- ── stg.Test ───────────────────────────────────────────────
CREATE TABLE stg.Test (
    src_TestID          VARCHAR(50)   NULL,
    src_TestName        VARCHAR(500)  NULL,
    src_TestType        VARCHAR(100)  NULL,
    src_AutomationFlag  VARCHAR(10)   NULL,
    src_Component       VARCHAR(200)  NULL,
    src_ApplicationID   VARCHAR(50)   NULL,
    src_Priority        VARCHAR(50)   NULL,
    src_IsActive        VARCHAR(10)   NULL,
    _LoadedAt           DATETIME2     NOT NULL DEFAULT SYSUTCDATETIME(),
    _RowStatus          VARCHAR(20)   NOT NULL DEFAULT 'Pending'
);
GO

-- ── stg.Defect ─────────────────────────────────────────────
CREATE TABLE stg.Defect (
    src_DefectID        VARCHAR(50)   NULL,
    src_DefectSummary   VARCHAR(1000) NULL,
    src_Severity        VARCHAR(50)   NULL,
    src_Status          VARCHAR(100)  NULL,
    src_AssignedTeam    VARCHAR(100)  NULL,
    src_LeakageFlag     VARCHAR(10)   NULL,
    src_ApplicationID   VARCHAR(50)   NULL,
    src_ReleaseFoundID  VARCHAR(50)   NULL,
    _LoadedAt           DATETIME2     NOT NULL DEFAULT SYSUTCDATETIME(),
    _RowStatus          VARCHAR(20)   NOT NULL DEFAULT 'Pending'
);
GO

-- ── stg.TestRun ────────────────────────────────────────────
-- Largest volume table — one row per Xray test execution
CREATE TABLE stg.TestRun (
    src_ExecutionID       VARCHAR(100)   NULL,
    src_TestID            VARCHAR(50)    NULL,
    src_RequirementID     VARCHAR(50)    NULL,
    src_ReleaseID         VARCHAR(50)    NULL,
    src_EnvironmentID     VARCHAR(50)    NULL,
    src_TesterID          VARCHAR(100)   NULL,
    src_StatusName        VARCHAR(50)    NULL,
    src_RootCauseName     VARCHAR(100)   NULL,
    src_ExecutionDate     VARCHAR(30)    NULL,
    src_ApplicationID     VARCHAR(50)    NULL,
    src_SquadID           VARCHAR(50)    NULL,
    src_RunSequence       VARCHAR(10)    NULL,
    src_IsAutomated       VARCHAR(10)    NULL,
    src_DurationMinutes   VARCHAR(20)    NULL,
    src_IsBlocked         VARCHAR(10)    NULL,
    src_BlockReason       VARCHAR(500)   NULL,
    src_LinkedDefectCount VARCHAR(10)    NULL,
    src_ExecutionSource   VARCHAR(50)    NULL,
    src_Comments          NVARCHAR(1000) NULL,
    _LoadedAt             DATETIME2      NOT NULL DEFAULT SYSUTCDATETIME(),
    _RowStatus            VARCHAR(20)    NOT NULL DEFAULT 'Pending'
);
GO

-- ── stg.RequirementCoverage ────────────────────────────────
CREATE TABLE stg.RequirementCoverage (
    src_RequirementID       VARCHAR(50)  NULL,
    src_ReleaseID           VARCHAR(50)  NULL,
    src_CoveredFlag         VARCHAR(10)  NULL,
    src_PartialCoverageFlag VARCHAR(10)  NULL,
    src_FailedCoverageFlag  VARCHAR(10)  NULL,
    src_LinkedTestCount     VARCHAR(10)  NULL,
    src_LatestExecutionDate VARCHAR(30)  NULL,
    _LoadedAt               DATETIME2    NOT NULL DEFAULT SYSUTCDATETIME(),
    _RowStatus              VARCHAR(20)  NOT NULL DEFAULT 'Pending'
);
GO

-- ── stg.DefectLink ─────────────────────────────────────────
CREATE TABLE stg.DefectLink (
    src_DefectID        VARCHAR(50)  NULL,
    src_ExecutionID     VARCHAR(100) NULL,
    src_RequirementID   VARCHAR(50)  NULL,
    src_ReleaseID       VARCHAR(50)  NULL,
    src_LinkType        VARCHAR(50)  NULL,
    src_OpenFlag        VARCHAR(10)  NULL,
    _LoadedAt           DATETIME2    NOT NULL DEFAULT SYSUTCDATETIME(),
    _RowStatus          VARCHAR(20)  NOT NULL DEFAULT 'Pending'
);
GO

PRINT 'Staging schema and tables created successfully.';
GO
