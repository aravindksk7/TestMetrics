-- ============================================================
-- Xray ETL Step 4: Load Fact Tables
-- Pattern : FactTestRun / FactDefectLink = INSERT new only
--           FactRequirementCoverage      = MERGE (upsert)
--           FactCycleSnapshot            = auto-generated from FactTestRun
-- ============================================================
USE XrayTestMetrics;
GO

DECLARE @BatchID UNIQUEIDENTIFIER = NEWID();
DECLARE @Rows    INT;
PRINT 'BatchID: ' + CAST(@BatchID AS VARCHAR(36));

-- ============================================================
-- 1. FactTestRun
--    Idempotency key: ExecutionID (unique per Xray execution)
--    New rows only — facts are immutable
-- ============================================================
INSERT stg.ETLLog (BatchID,TableName,StepName,RowsSource)
SELECT @BatchID,'FactTestRun','INSERT Start',COUNT(*) FROM stg.TestRun;

INSERT INTO dbo.FactTestRun (
    TestKey, RequirementKey, ReleaseKey, EnvironmentKey,
    TesterKey, StatusKey, RootCauseKey, ExecutionDateKey,
    ApplicationKey, SquadKey, ExecutionID, RunSequence,
    IsAutomated, DurationMinutes, IsBlocked, BlockReason,
    LinkedDefectCount, ExecutionSource, Comments
)
SELECT
    dt.TestKey,
    dreq.RequirementKey,
    dr.ReleaseKey,
    de.EnvironmentKey,
    dtt.TesterKey,
    ds.StatusKey,
    drc.RootCauseKey,
    dd.DateKey                                              AS ExecutionDateKey,
    da.ApplicationKey,
    dsq.SquadKey,
    LTRIM(RTRIM(s.src_ExecutionID))                        AS ExecutionID,
    ISNULL(TRY_CAST(s.src_RunSequence     AS TINYINT),  1) AS RunSequence,
    CASE UPPER(LTRIM(RTRIM(s.src_IsAutomated)))
        WHEN 'TRUE' THEN 1 WHEN 'YES' THEN 1 WHEN '1' THEN 1 ELSE 0 END AS IsAutomated,
    TRY_CAST(s.src_DurationMinutes        AS DECIMAL(8,2)) AS DurationMinutes,
    CASE UPPER(LTRIM(RTRIM(s.src_IsBlocked)))
        WHEN 'TRUE' THEN 1 WHEN 'YES' THEN 1 WHEN '1' THEN 1 ELSE 0 END AS IsBlocked,
    NULLIF(LTRIM(RTRIM(s.src_BlockReason)),'')             AS BlockReason,
    ISNULL(TRY_CAST(s.src_LinkedDefectCount AS SMALLINT),0) AS LinkedDefectCount,
    CASE UPPER(LTRIM(RTRIM(s.src_ExecutionSource)))
        WHEN 'MANUAL'    THEN 'Manual'
        WHEN 'CI/CD'     THEN 'CI/CD'
        WHEN 'SCHEDULED' THEN 'Scheduled'
        ELSE NULL
    END                                                     AS ExecutionSource,
    NULLIF(LTRIM(RTRIM(s.src_Comments)),'')                AS Comments
FROM stg.TestRun s
JOIN dbo.DimTest          dt   ON dt.TestID        = LTRIM(RTRIM(s.src_TestID))
JOIN dbo.DimRelease       dr   ON dr.ReleaseID     = LTRIM(RTRIM(s.src_ReleaseID))
JOIN dbo.DimEnvironment   de   ON de.EnvironmentID = LTRIM(RTRIM(s.src_EnvironmentID))
JOIN dbo.DimTester        dtt  ON dtt.TesterID     = LTRIM(RTRIM(s.src_TesterID))
JOIN dbo.DimStatus        ds   ON ds.StatusName    = UPPER(LTRIM(RTRIM(s.src_StatusName)))
JOIN dbo.DimRootCause     drc  ON drc.RootCauseName= LTRIM(RTRIM(s.src_RootCauseName))
JOIN dbo.DimDate          dd   ON dd.FullDate      = TRY_CAST(s.src_ExecutionDate AS DATE)
LEFT JOIN dbo.DimRequirement dreq ON dreq.RequirementID = LTRIM(RTRIM(s.src_RequirementID))
LEFT JOIN dbo.DimApplication da   ON da.ApplicationID   = LTRIM(RTRIM(s.src_ApplicationID))
LEFT JOIN dbo.DimSquad       dsq  ON dsq.SquadID        = LTRIM(RTRIM(s.src_SquadID))
-- Idempotency guard: skip already-loaded executions
WHERE NOT EXISTS (
    SELECT 1 FROM dbo.FactTestRun f
    WHERE f.ExecutionID = LTRIM(RTRIM(s.src_ExecutionID))
)
AND TRY_CAST(s.src_ExecutionDate AS DATE) IS NOT NULL
AND LTRIM(RTRIM(ISNULL(s.src_ExecutionID,''))) <> '';

SET @Rows = @@ROWCOUNT;
UPDATE stg.ETLLog SET EndTime=SYSUTCDATETIME(),Status='Success',RowsInserted=@Rows
WHERE BatchID=@BatchID AND TableName='FactTestRun';
PRINT 'FactTestRun: ' + CAST(@Rows AS VARCHAR) + ' rows inserted.';

-- Warn on rejected staging rows (failed key lookups)
DECLARE @Rejected INT;
SELECT @Rejected = COUNT(*) FROM stg.TestRun s
WHERE LTRIM(RTRIM(ISNULL(s.src_ExecutionID,''))) <> ''
  AND NOT EXISTS (SELECT 1 FROM dbo.DimTest dt WHERE dt.TestID = LTRIM(RTRIM(s.src_TestID)));
IF @Rejected > 0
    PRINT 'WARNING: ' + CAST(@Rejected AS VARCHAR) +
          ' TestRun rows rejected — TestID not found in DimTest. Check stg.TestRun.';

-- ============================================================
-- 2. FactRequirementCoverage
--    MERGE on RequirementKey + ReleaseKey (coverage changes over time)
-- ============================================================
INSERT stg.ETLLog (BatchID,TableName,StepName,RowsSource)
SELECT @BatchID,'FactRequirementCoverage','MERGE Start',COUNT(*) FROM stg.RequirementCoverage;

MERGE dbo.FactRequirementCoverage AS tgt
USING (
    SELECT
        dreq.RequirementKey,
        dr.ReleaseKey,
        CASE UPPER(LTRIM(RTRIM(s.src_CoveredFlag)))
            WHEN 'TRUE' THEN 1 WHEN 'YES' THEN 1 WHEN '1' THEN 1 ELSE 0 END AS CoveredFlag,
        CASE UPPER(LTRIM(RTRIM(s.src_PartialCoverageFlag)))
            WHEN 'TRUE' THEN 1 WHEN 'YES' THEN 1 WHEN '1' THEN 1 ELSE 0 END AS PartialCoverageFlag,
        CASE UPPER(LTRIM(RTRIM(s.src_FailedCoverageFlag)))
            WHEN 'TRUE' THEN 1 WHEN 'YES' THEN 1 WHEN '1' THEN 1 ELSE 0 END AS FailedCoverageFlag,
        ISNULL(TRY_CAST(s.src_LinkedTestCount AS SMALLINT),0) AS LinkedTestCount,
        dd.DateKey AS LatestExecutionDateKey
    FROM stg.RequirementCoverage s
    JOIN dbo.DimRequirement dreq ON dreq.RequirementID = LTRIM(RTRIM(s.src_RequirementID))
    JOIN dbo.DimRelease     dr   ON dr.ReleaseID       = LTRIM(RTRIM(s.src_ReleaseID))
    LEFT JOIN dbo.DimDate   dd   ON dd.FullDate = TRY_CAST(s.src_LatestExecutionDate AS DATE)
    WHERE LTRIM(RTRIM(ISNULL(s.src_RequirementID,''))) <> ''
) src ON tgt.RequirementKey = src.RequirementKey AND tgt.ReleaseKey = src.ReleaseKey
WHEN MATCHED AND (
    tgt.CoveredFlag         <> src.CoveredFlag         OR
    tgt.PartialCoverageFlag <> src.PartialCoverageFlag OR
    tgt.FailedCoverageFlag  <> src.FailedCoverageFlag  OR
    tgt.LinkedTestCount     <> src.LinkedTestCount
) THEN UPDATE SET
    CoveredFlag            = src.CoveredFlag,
    PartialCoverageFlag    = src.PartialCoverageFlag,
    FailedCoverageFlag     = src.FailedCoverageFlag,
    LinkedTestCount        = src.LinkedTestCount,
    LatestExecutionDateKey = src.LatestExecutionDateKey,
    ModifiedDate           = SYSUTCDATETIME()
WHEN NOT MATCHED BY TARGET THEN
    INSERT (RequirementKey,ReleaseKey,CoveredFlag,PartialCoverageFlag,
            FailedCoverageFlag,LinkedTestCount,LatestExecutionDateKey)
    VALUES (src.RequirementKey,src.ReleaseKey,src.CoveredFlag,src.PartialCoverageFlag,
            src.FailedCoverageFlag,src.LinkedTestCount,src.LatestExecutionDateKey);

SET @Rows = @@ROWCOUNT;
UPDATE stg.ETLLog SET EndTime=SYSUTCDATETIME(),Status='Success',RowsInserted=@Rows
WHERE BatchID=@BatchID AND TableName='FactRequirementCoverage';
PRINT 'FactRequirementCoverage: ' + CAST(@Rows AS VARCHAR) + ' rows merged.';

-- ============================================================
-- 3. FactDefectLink
--    INSERT new links only — deduped on DefectKey + TestRunKey
-- ============================================================
INSERT stg.ETLLog (BatchID,TableName,StepName,RowsSource)
SELECT @BatchID,'FactDefectLink','INSERT Start',COUNT(*) FROM stg.DefectLink;

INSERT INTO dbo.FactDefectLink (
    DefectKey, TestRunKey, RequirementKey, ReleaseKey, LinkType, OpenFlag
)
SELECT
    ddef.DefectKey,
    ftr.TestRunKey,
    dreq.RequirementKey,
    dr.ReleaseKey,
    CASE UPPER(LTRIM(RTRIM(s.src_LinkType)))
        WHEN 'CAUSED BY' THEN 'Caused By'
        WHEN 'BLOCKS'    THEN 'Blocks'
        WHEN 'RELATED'   THEN 'Related'
        WHEN 'DUPLICATE' THEN 'Duplicate'
        ELSE 'Related'
    END AS LinkType,
    CASE UPPER(LTRIM(RTRIM(s.src_OpenFlag)))
        WHEN 'TRUE' THEN 1 WHEN 'YES' THEN 1 WHEN '1' THEN 1 ELSE 0 END AS OpenFlag
FROM stg.DefectLink s
JOIN dbo.DimDefect        ddef ON ddef.DefectID   = LTRIM(RTRIM(s.src_DefectID))
JOIN dbo.FactTestRun      ftr  ON ftr.ExecutionID = LTRIM(RTRIM(s.src_ExecutionID))
JOIN dbo.DimRelease       dr   ON dr.ReleaseID    = LTRIM(RTRIM(s.src_ReleaseID))
LEFT JOIN dbo.DimRequirement dreq ON dreq.RequirementID = LTRIM(RTRIM(s.src_RequirementID))
WHERE NOT EXISTS (
    SELECT 1 FROM dbo.FactDefectLink f
    WHERE f.DefectKey  = ddef.DefectKey
      AND f.TestRunKey = ftr.TestRunKey
);

SET @Rows = @@ROWCOUNT;
UPDATE stg.ETLLog SET EndTime=SYSUTCDATETIME(),Status='Success',RowsInserted=@Rows
WHERE BatchID=@BatchID AND TableName='FactDefectLink';
PRINT 'FactDefectLink: ' + CAST(@Rows AS VARCHAR) + ' rows inserted.';

-- ============================================================
-- 4. FactCycleSnapshot
--    Auto-derived from FactTestRun — no CSV required
--    One row per DateKey + Program + Application + Release
-- ============================================================
INSERT stg.ETLLog (BatchID,TableName,StepName) VALUES (@BatchID,'FactCycleSnapshot','INSERT Start');

INSERT INTO dbo.FactCycleSnapshot (
    SnapshotDateKey, ProgramKey, ApplicationKey, ReleaseKey, EnvironmentKey,
    TotalTests, ExecutedTests, PassedTests, FailedTests, BlockedTests,
    NotRunTests, AutomatedExecutions, ManualExecutions,
    CoveredRequirements, TotalRequirements,
    OpenCriticalDefects, TotalRerunCount, AvgDurationMinutes
)
SELECT
    ftr.ExecutionDateKey                                          AS SnapshotDateKey,
    dp.ProgramKey,
    da.ApplicationKey,
    ftr.ReleaseKey,
    ftr.EnvironmentKey,
    COUNT(DISTINCT dt.TestKey)                                    AS TotalTests,
    COUNT(*)                                                      AS ExecutedTests,
    SUM(CASE WHEN ds.StatusCategory = 'Pass'    THEN 1 ELSE 0 END) AS PassedTests,
    SUM(CASE WHEN ds.StatusCategory = 'Fail'    THEN 1 ELSE 0 END) AS FailedTests,
    SUM(CASE WHEN ds.StatusCategory = 'Blocked' THEN 1 ELSE 0 END) AS BlockedTests,
    SUM(CASE WHEN ds.StatusCategory = 'Pending' THEN 1 ELSE 0 END) AS NotRunTests,
    SUM(CASE WHEN ftr.IsAutomated = 1           THEN 1 ELSE 0 END) AS AutomatedExecutions,
    SUM(CASE WHEN ftr.IsAutomated = 0           THEN 1 ELSE 0 END) AS ManualExecutions,
    (   SELECT COUNT(DISTINCT frc.RequirementKey)
        FROM dbo.FactRequirementCoverage frc
        WHERE frc.ReleaseKey = ftr.ReleaseKey AND frc.CoveredFlag = 1
    )                                                              AS CoveredRequirements,
    (   SELECT COUNT(DISTINCT frc2.RequirementKey)
        FROM dbo.FactRequirementCoverage frc2
        WHERE frc2.ReleaseKey = ftr.ReleaseKey
    )                                                              AS TotalRequirements,
    (   SELECT COUNT(DISTINCT d.DefectID)
        FROM dbo.DimDefect d
        WHERE d.Severity IN ('Critical','Sev1')
          AND d.Status NOT IN ('Closed','Resolved')
    )                                                              AS OpenCriticalDefects,
    SUM(CASE WHEN ftr.RunSequence > 1           THEN 1 ELSE 0 END) AS TotalRerunCount,
    AVG(ftr.DurationMinutes)                                       AS AvgDurationMinutes
FROM dbo.FactTestRun    ftr
JOIN dbo.DimTest        dt  ON ftr.TestKey        = dt.TestKey
JOIN dbo.DimStatus      ds  ON ftr.StatusKey      = ds.StatusKey
JOIN dbo.DimApplication da  ON ftr.ApplicationKey = da.ApplicationKey
JOIN dbo.DimProgram     dp  ON da.ProgramKey      = dp.ProgramKey
-- Only insert snapshots not yet loaded
WHERE NOT EXISTS (
    SELECT 1 FROM dbo.FactCycleSnapshot snap
    WHERE snap.SnapshotDateKey = ftr.ExecutionDateKey
      AND snap.ApplicationKey  = ftr.ApplicationKey
      AND snap.ReleaseKey      = ftr.ReleaseKey
      AND snap.EnvironmentKey  = ftr.EnvironmentKey
)
GROUP BY
    ftr.ExecutionDateKey, dp.ProgramKey,
    da.ApplicationKey, ftr.ReleaseKey, ftr.EnvironmentKey;

SET @Rows = @@ROWCOUNT;
UPDATE stg.ETLLog SET EndTime=SYSUTCDATETIME(),Status='Success',RowsInserted=@Rows
WHERE BatchID=@BatchID AND TableName='FactCycleSnapshot';
PRINT 'FactCycleSnapshot: ' + CAST(@Rows AS VARCHAR) + ' rows inserted.';

PRINT 'All fact tables loaded. Proceed to Step 5 (DQ checks).';
GO
